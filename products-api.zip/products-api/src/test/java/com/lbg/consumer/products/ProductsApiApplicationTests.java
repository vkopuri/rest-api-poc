package com.lbg.consumer.products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
