package com.lbg.consumer.products.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.consumer.products.service.ConfigLoaderService;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Map;

@RestController
@AllArgsConstructor
@Hidden
public class DynamicEndpointController {

    private ConfigLoaderService configLoaderService;

    @RequestMapping("/api/dynamic/**")
    public ResponseEntity<?> handle(HttpServletRequest request,
                                    @RequestBody(required = false) String body,
                                    HttpMethod method) throws JsonProcessingException {
        String path = request.getRequestURI();
        return configLoaderService.getEndpoint(path, method)
                .map(ep -> {
                    try {
                        String response = new ObjectMapper().writeValueAsString(Map.of(
                                "timestamp", Instant.now().toString(),
                                "status", 200,
                                "message", "Success.",
                                "path", path,
                                "body", ep.getResponse()
                        ));
                        return ResponseEntity.ok(response);
                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ObjectMapper().writeValueAsString(Map.of(
                        "timestamp", Instant.now().toString(),
                        "status", 400,
                        "message", "Resource Not Found.",
                        "path", path))));
    }
}
