package com.lbg.consumer.products.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DynamicEndpoint {
    private String path;
    private String method;
    private String response;
    private boolean deprecated;
}
