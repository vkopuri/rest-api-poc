package com.lbg.consumer.products.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Data
@ConfigurationProperties(prefix = "tenant")
public class TenantProperties {
    private List<String> securedPaths = new ArrayList<>();
}
