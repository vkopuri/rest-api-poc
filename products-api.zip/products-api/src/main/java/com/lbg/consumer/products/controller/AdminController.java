package com.lbg.consumer.products.controller;

import com.lbg.consumer.products.service.ConfigLoaderService;
import com.lbg.consumer.products.service.ProductService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/admin")
@AllArgsConstructor
public class AdminController {

    private ConfigLoaderService configLoaderService;

    private ProductService productService;

    @GetMapping("/tenants")
    public ResponseEntity<?> getTenantS() {

        return ResponseEntity.ok(configLoaderService.getTenantConfigs());
    }

    @GetMapping("/products")
    public ResponseEntity<?> getProducts() {
        return ResponseEntity.ok(productService.getProducts());
    }
}
