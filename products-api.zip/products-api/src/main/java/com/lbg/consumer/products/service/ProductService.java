package com.lbg.consumer.products.service;

import com.lbg.consumer.products.model.Product;
import com.lbg.consumer.products.model.Tenant;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class ProductService {

    private ConfigLoaderService configService;

    public List<Product> getProductsForTenant(Tenant config) {
        return configService.getAllProducts().stream()
                .filter(p -> config.getAllowedProducts().contains(p.getId()))
                .collect(Collectors.toList());
    }

    public List<Product> getProducts() {
        return configService.getAllProducts();
    }
}