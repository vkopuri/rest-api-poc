package com.lbg.consumer.products.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.consumer.products.model.DynamicEndpoint;
import com.lbg.consumer.products.model.Product;
import com.lbg.consumer.products.model.Tenant;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@RefreshScope
@Service
@Getter
public class ConfigLoaderService {

    private final Map<String, Tenant> tenantConfigs = new HashMap<>();

    private List<Product> allProducts = new ArrayList<>();
    private final Map<String, DynamicEndpoint> endpointMap = new ConcurrentHashMap<>();

    @PostConstruct
    public void loadConfig() throws IOException {

        System.out.println("Loading config...");

        ObjectMapper mapper = new ObjectMapper();
        InputStream is = new FileInputStream("config/products-api-config.json");
        JsonNode root = mapper.readTree(is);

        // Load tenants
        JsonNode tenantsNode = root.get("tenants");
        tenantsNode.properties().forEach(entry -> {
            Tenant config = mapper.convertValue(entry.getValue(), Tenant.class);
            tenantConfigs.put(entry.getKey(), config);
        });

        // Load products
        JsonNode productsNode = root.get("products");
        allProducts = Arrays.asList(mapper.treeToValue(productsNode, Product[].class));

        // Load endpoints
        JsonNode endpointNode = root.get("endpoints");
        DynamicEndpoint[] endpoints = mapper.treeToValue(endpointNode, DynamicEndpoint[].class);
        endpointMap.clear();
        for (DynamicEndpoint ep : endpoints) {
            if(!ep.isDeprecated()){
                String key = ep.getMethod().toUpperCase() + ":" + ep.getPath();
                endpointMap.put(key, ep);
            }
        }
    }

    public Tenant getTenantConfig(String tenantId) {
        return tenantConfigs.get(tenantId);
    }

    public Optional<DynamicEndpoint> getEndpoint(String path, HttpMethod method) {
        return Optional.ofNullable(endpointMap.get(method.name() + ":" + path));
    }
}

