package com.lbg.consumer.products.model;

import lombok.Data;

import java.util.List;

@Data
public class Tenant {
    private String id;
    private List<String> allowedProducts;
}

