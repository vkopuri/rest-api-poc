package com.lbg.consumer.products.middleware;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.consumer.products.config.TenantProperties;
import com.lbg.consumer.products.service.ConfigLoaderService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;

@Component
@AllArgsConstructor
public class TenantInterceptor implements HandlerInterceptor {

    private final PathMatcher pathMatcher = new AntPathMatcher();
    private ConfigLoaderService configService;
    private TenantProperties tenantProperties;

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws IOException {

        String path = request.getRequestURI();
        // Wildcard match
        boolean isSecured = tenantProperties.getSecuredPaths().stream()
                .anyMatch(pattern -> pathMatcher.match(pattern, path));

        if (isSecured) {
            String tenantId = request.getHeader("X-Tenant-ID");
            if (tenantId == null || configService.getTenantConfig(tenantId) == null) {
                response.setStatus(HttpStatus.UNAUTHORIZED.value());
                response.getWriter().write(new ObjectMapper().writeValueAsString(Map.of(
                        "timestamp", Instant.now().toString(),
                        "status", 401,
                        "error", "Unauthorized",
                        "message", "Invalid or missing tenant ID. Please provide a valid X-Tenant-ID header.",
                        "path", path
                )));
                return false;
            }
            request.setAttribute("tenantConfig", configService.getTenantConfig(tenantId));
        }


//        String authHeader = request.getHeader("Authorization");
//        if (authHeader != null && authHeader.startsWith("Bearer ")) {
//            String token = authHeader.substring(7);
//            Claims claims = Jwts.parser()
//                    .setSigningKey(secretKey)
//                    .parseClaimsJws(token)
//                    .getBody();
//            String tenantId = claims.get("tenant_id", String.class);
//        }

        return true;
    }
}

