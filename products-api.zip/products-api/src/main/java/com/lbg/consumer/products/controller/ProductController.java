package com.lbg.consumer.products.controller;

import com.lbg.consumer.products.model.Product;
import com.lbg.consumer.products.model.Tenant;
import com.lbg.consumer.products.service.ProductService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@AllArgsConstructor
public class ProductController {

    private final ProductService productService;

    @GetMapping
    public ResponseEntity<List<Product>> getProducts(HttpServletRequest request) {
        Tenant config = (Tenant) request.getAttribute("tenantConfig");
        return ResponseEntity.ok(productService.getProductsForTenant(config));
    }
}
